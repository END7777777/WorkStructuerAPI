import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpService } from '../http.service';
import { Employee } from '../model/employee';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  empobj:any=<Employee>{};
  
  constructor (private route: ActivatedRoute, private service:HttpService){}
  ngOnInit(): void {
   this.getdatafromUrL();
  }

  getdatafromUrL(){
    this.route.paramMap.subscribe((par)=>{
      // console.log(par.get("id"));
      this.getdatafrombackend(par.get("id"));
    })
  }

  getdatafrombackend(id:any){
    this.service.getempbyid(id).subscribe((res)=>{
      // console.log(res);
      this.empobj=res;
    })
  }
}
