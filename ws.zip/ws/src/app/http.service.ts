import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http:HttpClient) { }
baseurl1:string="http://localhost:8080/EAPI/";
baseurl2:string="http://localhost:8080/API/";

  getAllEmp(){
    return (this.http.get(`${this.baseurl1}getALLEMP`));
  }

  getempbyid(id:any){
    return (this.http.get(`${this.baseurl1}EMPbyID/${id}`));
  }

  getallcountry(){
    return (this.http.get(`${this.baseurl2}getallcountry`));
  }

  postempdata(obj:any){
    return (this.http.post(`${this.baseurl1}addemp`,obj,{
      responseType:'text'
    }));
  }

  
  updateEmpData(obj:any){
    return (this.http.put(`${this.baseurl1}updateEmploye/${obj.id}`,obj,{
       responseType:'text'
     }));
 }

 deleteData(id:any){
  return (this.http.delete(`${this.baseurl1}DeleteEmp/${id}`,{
     responseType:'text'
   }));
 }

}

